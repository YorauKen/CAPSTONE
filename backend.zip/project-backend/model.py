import clip
import shutil
from torch import nn
from PIL import Image
import torch
import matplotlib.pyplot as plt
import cv2
from insightface.app import FaceAnalysis
from insightface.model_zoo import get_model
from transformers import CLIPTokenizer
import torchvision.transforms as transforms
from junk import NetG,CLIP_IMG_ENCODER,CLIP_TXT_ENCODER,CLIP_Model
import numpy as np
import os

# !pip install insightface
# !pip install onnxruntime

# model_path 
class FaceSwapper:
    _instance = None

    def __new__(cls, model_path=r'D:\Dataset\Capfront\backend\models\inswapper_128.onnx', ctx_id=0, det_size=(640, 640)):
        if cls._instance is None:
            cls._instance = super(FaceSwapper, cls).__new__(cls)
            
            # Initialize FaceAnalysis
            cls._instance.app = FaceAnalysis(name='buffalo_l')
            cls._instance.app.prepare(ctx_id=ctx_id, det_size=det_size)
            
            # Load the face-swapping model
            assert os.path.exists(model_path), f"Model file not found at {model_path}"
            cls._instance.swapper = get_model(model_path, download=False, download_zip=False)

        return cls._instance

    def swap_faces(self, generated_image, default_image_path):
        # Load the default image
        assert os.path.exists(default_image_path), f"Default image not found at {default_image_path}"
        default_image = cv2.imread(default_image_path)

        # Convert PIL image to OpenCV format
        generated_image_cv = cv2.cvtColor(np.array(generated_image), cv2.COLOR_RGB2BGR)

        # Detect faces in both images
        default_face = self.app.get(default_image)[0]
        fake_faces = self.app.get(generated_image_cv)

        # Perform face swapping
        result_image = generated_image_cv.copy()
        for face in fake_faces:
            result_image = self.swapper.get(result_image, face, default_face, paste_back=True)

        # Convert back to PIL format
        result_image_pil = Image.fromarray(cv2.cvtColor(result_image, cv2.COLOR_BGR2RGB))

        return result_image_pil


class GALIP_CONTAINER:
    def __init__(self, netG, text_encoder, image_encoder):
        self.netG = netG
        self.text_encoder = text_encoder
        self.image_encoder = image_encoder

class Model:
    _instance = None  # Class-level attribute to hold the singleton instance

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            # Create a new instance if one doesn't already exist
            cls._instance = super(Model, cls).__new__(cls)
        return cls._instance

    def __init__(self,CLIP, load_path=r'D:\Dataset\Capfront\backend\models\state_epoch_120_001.pth'):
        # Ensure the singleton is initialized only once
        if not hasattr(self, "initialized"):
            self.GALIP = self._initialize_galip(CLIP)
            self.tokenizer = CLIPTokenizer.from_pretrained("openai/clip-vit-base-patch32")
            self.load_model_galip(load_path)
            self.device='cuda'
            self.initialized = True  # Mark the instance as initialized

    def _initialize_galip(self,CLIP):
        # Placeholder logic for initializing GALIP components
        netG = nn.DataParallel(NetG(CLIP,ngf=64, nz=100, cond_dim=512, imsize=224, ch_size=3, mixed_precision=True))
        text_encoder = CLIP_TXT_ENCODER(CLIP)
        image_encoder = CLIP_IMG_ENCODER(CLIP)

        # Create and return the GALIP_CONTAINER object
        return GALIP_CONTAINER(netG, text_encoder, image_encoder)

    def load_model_galip(self, load_path):
        checkpoint = torch.load(load_path, map_location=torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
        
        # Loading model components
        self.GALIP.netG.load_state_dict(checkpoint['model']['netG'], strict=False)
        self.GALIP.text_encoder.load_state_dict(checkpoint['model']['text_encoder'], strict=False)
        self.GALIP.image_encoder.load_state_dict(checkpoint['model']['image_encoder'], strict=False)
        
        return checkpoint['epoch']
    

    def test_model(self, caption, z_dim=100, num_samples=6, upscale_size=(512, 512)):
        self.GALIP.netG.eval()  # Set the generator to evaluation mode
        transform = transforms.ToPILImage()  # Convert the image tensor to PIL format
        fifth_image = None
        input_ids = self.tokenizer(caption, padding='max_length', truncation=True, max_length=77, return_tensors="pt").input_ids.to(self.device)
        with torch.no_grad():  # No need to calculate gradients during testing
            for i in range(num_samples):
                # Generate random noise
                noise = torch.randn(1, z_dim).to(self.device)
                
                # Get caption embeddings using the text encoder
                caption_emb, word_embeds = self.GALIP.text_encoder(input_ids)
                
                # Generate a fake image using the generator
                fake_image = self.GALIP.netG(noise, caption_emb)
                
                # Assuming the generated image is normalized [-1, 1], denormalize it to [0, 1]
                fake_image = (fake_image.squeeze(0) * 0.5 + 0.5).clamp(0, 1)
                
                # Convert to PIL image
                pil_image = transform(fake_image.cpu())
                upscaled_image = pil_image.resize(upscale_size, Image.LANCZOS)
                
                # Store the 5th image
                if i == 4:
                    fifth_image = upscaled_image

        return fifth_image
