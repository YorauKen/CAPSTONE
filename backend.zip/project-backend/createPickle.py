import os
import joblib
import psycopg2
import numpy as np
from PIL import Image
from torchvision import transforms
from torch import nn
import torch
from scipy.stats import wasserstein_distance
from torchvision.models import resnet152
import cv2
import io

# Configuration settings
DB_CONFIG = {
    "dbname": "GenTest",
    "user": "****",
    "password": "T****",
    "host": "localhost",
    "port": 5432
}
CACHE_DIR = "cache_files"
os.makedirs(CACHE_DIR, exist_ok=True)

# Define your feature extractors
class ColorFeatureExtractor:
    def __init__(self, bins=64):
        self.bins = bins

    def extract_color_histogram(self, img):
        hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
        hist = cv2.calcHist([hsv], [0, 1, 2], None, [self.bins]*3, [0, 256, 0, 256, 0, 256])
        hist = cv2.normalize(hist, hist).flatten()
        return hist

class EnhancedResidualNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.model = nn.Sequential(*list(nn.Sequential(*list(resnet152(pretrained=True).children())[:-1]).children()))

    def forward(self, x):
        with torch.no_grad():
            return self.model(x).flatten()

class TableFeatureExtractor:
    def __init__(self):
        try:
            self.conn = psycopg2.connect(**DB_CONFIG)
            print("Successfully connected to the database.")
        except Exception as e:
            print(f"Error connecting to database: {e}")
            raise

        self.color_extractor = ColorFeatureExtractor()
        self.structural_model = EnhancedResidualNet().to(device)
        self.structural_model.eval()
        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

    def binary_to_image(self, binary_data):
        try:
            bytes_io = io.BytesIO(binary_data)
            image = Image.open(bytes_io).convert('RGB')
            return np.array(image)
        except Exception as e:
            print(f"Error converting binary data to image: {e}")
            return None

    def process_table(self, table_name):
        cache_path = os.path.join(CACHE_DIR, f"{table_name}.pkl")
        if os.path.exists(cache_path):
            print(f"Pickle file for {table_name} already exists at {cache_path}.")
            return

        print(f"Processing table: {table_name}")
        samples = []
        try:
            with self.conn.cursor() as cur:
                query = f"SELECT id, image_data FROM {table_name};"
                cur.execute(query)
                rows = cur.fetchall()

            for img_id, img_data in rows:
                try:
                    img = self.binary_to_image(img_data)
                    if img is None:
                        continue

                    # Extract color features
                    color_hist = self.color_extractor.extract_color_histogram(img)

                    # Convert to tensor and extract structural features
                    img_tensor = self.transform(Image.fromarray(img)).unsqueeze(0).to(device)
                    structural_feat = self.structural_model(img_tensor).cpu().numpy()

                    samples.append({
                        'id': img_id,
                        'features': {
                            'structural': structural_feat,
                            'color': color_hist
                        }
                    })
                    print(f"Processed image ID: {img_id}")
                except Exception as e:
                    print(f"Error processing image {img_id}: {e}")
                    continue

            with open(cache_path, 'wb') as f:
                joblib.dump(samples, f)
            print(f"Saved pickle file for {table_name} at {cache_path}")
        except Exception as e:
            print(f"Error processing table {table_name}: {e}")

    def __del__(self):
        if hasattr(self, 'conn'):
            self.conn.close()

if __name__ == "__main__":
    table_names = ["indowestern", "kurta", "sherwani", "nehru_jacket"]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    extractor = TableFeatureExtractor()

    for table in table_names:
        extractor.process_table(table)
