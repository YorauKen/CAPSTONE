import psycopg2
import base64
import os
import numpy as np
from PIL import Image
import torch
from torchvision import transforms
from torch import nn
from torchvision.models import resnet152
from scipy.stats import wasserstein_distance
from sklearn.preprocessing import StandardScaler
import joblib
import io
import cv2

# Database configuration
DB_CONFIG = {
    "dbname": "GenTest",
    "user": "****",
    "password": "****",
    "host": "localhost",
    "port": 5432
}

# Directory for cached features
CACHE_DIR = os.path.join(os.path.dirname(__file__), "cache_files")

# Constants
COLOR_BINS = 64
COLOR_WEIGHT = 0.9
STRUCTURAL_WEIGHT = 0.3
use_gpu = torch.cuda.is_available()
device = torch.device("cuda" if use_gpu else "cpu")

# Keyword mapping for descriptions
KEYWORD_MAPPING = {
    "indowestern": ["indo", "western", "indowestern"],
    "kurta": ["kurta"],
    "sherwani": ["sherwani"],
    "nehru_jacket": ["jacket", "nehru", "nehru jacket", "nehrujacket"]
}


class ColorFeatureExtractor:
    def __init__(self, bins=COLOR_BINS):
        self.bins = bins

    def extract_color_histogram(self, img):
        hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
        hist = cv2.calcHist([hsv], [0, 1, 2], None, [self.bins] * 3, [0, 256, 0, 256, 0, 256])
        hist = cv2.normalize(hist, hist).flatten()
        return hist


class EnhancedResidualNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.model = resnet152(weights='IMAGENET1K_V1')

    def forward(self, x):
        x = self.model.conv1(x)
        x = self.model.bn1(x)
        x = self.model.relu(x)
        x = self.model.maxpool(x)
        x = self.model.layer1(x)
        x = self.model.layer2(x)
        x = self.model.layer3(x)
        x = self.model.layer4(x)
        avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        return avg_pool(x).view(x.size(0), -1)


class EnhancedSimilarImageFinder:
    def __init__(self, db_config, top_k=5):
        """
        Initialize the finder with database configuration and top-k value.

        Args:
            db_config (dict): Database configuration dictionary.
            top_k (int): Number of top similar images to retrieve.
        """
        self.db_config = db_config
        self.top_k = top_k
        self.color_extractor = ColorFeatureExtractor()
        self.model = EnhancedResidualNet().to(device).eval()
        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

    def binary_to_image(self, binary_data):
        """Convert binary data to an image."""
        try:
            bytes_io = io.BytesIO(binary_data)
            image = Image.open(bytes_io).convert('RGB')
            return np.array(image)
        except Exception as e:
            print(f"Error converting binary data to image: {e}")
            return None

    def select_pickle_file(self, description):
        """Determine the appropriate pickle file based on description."""
        description = description.lower()
        for category, keywords in KEYWORD_MAPPING.items():
            if any(keyword in description for keyword in keywords):
                return os.path.join(CACHE_DIR, f"{category}.pkl")
        return None

    def load_features(self, pickle_path):
        """Load precomputed features from a pickle file."""
        if os.path.exists(pickle_path):
            with open(pickle_path, 'rb') as f:
                return joblib.load(f)
        else:
            raise FileNotFoundError(f"Pickle file not found at: {pickle_path}")

    def compute_distance(self, feat1, feat2):
        """Compute similarity distance between two feature sets."""
        structural_dist = np.linalg.norm(feat1['structural'] - feat2['structural'])
        color_dist = wasserstein_distance(feat1['color'], feat2['color'])
        return STRUCTURAL_WEIGHT * structural_dist + COLOR_WEIGHT * color_dist

    def find_similar_images(self, query_img_path, description):
        """
        Find similar images based on query image and description.

        Args:
            query_img_path (str): Path to the query image.
            description (str): Text description for filtering.

        Returns:
            list[tuple]: List of (distance, image_id) tuples.
        """
        # Load and preprocess query image
        query_img = np.array(Image.open(query_img_path).convert('RGB'))
        color_hist = self.color_extractor.extract_color_histogram(query_img)
        query_tensor = self.transform(Image.fromarray(query_img)).unsqueeze(0).to(device)

        with torch.no_grad():
            structural_feat = self.model(query_tensor).cpu().numpy().flatten()

        query_features = {'structural': structural_feat, 'color': color_hist}

        # Select the appropriate pickle file
        pickle_path = self.select_pickle_file(description)
        if not pickle_path:
            print("No matching category found for the description.")
            return []

        # Load features from pickle file
        samples = self.load_features(pickle_path)
        distances = [(self.compute_distance(query_features, sample['features']), sample['id']) for sample in samples]
        distances.sort(key=lambda x: x[0])

        return distances[:self.top_k]

    def find_similar_with_description(self, query_img_path, description):
        """
        Find similar images with metadata based on query image and description.

        Args:
            query_img_path (str): Path to the query image.
            description (str): Text description to refine the search.

        Returns:
            list[dict]: List of similar images with metadata (title, image data, link, distance).
        """
        try:
            # Find similar images
            similar_images = self.find_similar_images(query_img_path, description)

            # Fetch metadata from database
            conn = psycopg2.connect(**self.db_config)
            with conn.cursor() as cur:
                img_ids = [img_id for _, img_id in similar_images]
                cur.execute(
                    "SELECT id, image_data, link, description FROM images WHERE id IN %s",
                    (tuple(img_ids),)
                )
                fetched_data = cur.fetchall()

            # Map fetched data by image ID
            img_data_map = {row[0]: row[1:] for row in fetched_data}

            # Prepare the response
            response = []
            for distance, img_id in similar_images:
                if img_id not in img_data_map:
                    continue

                img_data, link, desc = img_data_map[img_id]
                img_data_base64 = base64.b64encode(img_data).decode("utf-8")

                response.append({
                    "title": desc,
                    "image_data": img_data_base64,
                    "link": link,
                    "distance": round(distance, 2),
                })

            return response

        except Exception as e:
            raise Exception(f"Error in find_similar_with_description: {str(e)}")
