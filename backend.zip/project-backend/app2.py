from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from pydantic import BaseModel
from fastapi.responses import StreamingResponse, JSONResponse
from io import BytesIO
import base64
from PIL import Image
import os
from simi2 import EnhancedSimilarImageFinder
from model import Model, FaceSwapper
from junk import CLIP_Model
from fastapi.middleware.cors import CORSMiddleware

# Database configuration
DB_CONFIG = {
    "dbname": "GenTest",
    "user": "****",
    "password": "****",
    "host": "localhost",
    "port": 5432
}

# Initialize the Similar Image Finder
similar_image_finder = EnhancedSimilarImageFinder(DB_CONFIG)

# Initialize the model and face swapper for image generation
CLIP, _ = CLIP_Model.get_model()
model = Model(CLIP)
face_swapper = FaceSwapper()

# FastAPI app
app = FastAPI()

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Update this for specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Endpoint for generating images from text input
class TextInput(BaseModel):
    text: str

@app.post("/generate")
async def generate_image(input: TextInput):
    """
    API endpoint to generate an image based on text input.
    """
    try:
        # Generate an image using the generator model
        image = model.test_model(input.text)
        swapped_image = face_swapper.swap_faces(image, r'D:\Dataset\Capfront\backend\models\default_image.jpg')

        img_byte_arr = BytesIO()
        swapped_image.save(img_byte_arr, format="PNG")
        img_byte_arr.seek(0)

        # Return the image as a streaming response
        return StreamingResponse(img_byte_arr, media_type="image/png")

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating image: {str(e)}")


# Endpoint to find similar images
@app.post("/find-similar")
async def find_similar_images_endpoint(
    file: UploadFile = File(...),
    description: str = Form(...)
):
    """
    Endpoint to find similar images based on a query image and description.
    Accepts an image file and a description, and returns a JSON response with similar image details.
    """
    try:
        # Save the uploaded file temporarily
        contents = await file.read()
        temp_path = r"D:\Dataset\Capfront\backend\models\temp_query_image.jpg"
        with open(temp_path, "wb") as temp_file:
            temp_file.write(contents)

        # Call the method from simi2.py to find similar images
        response = similar_image_finder.find_similar_with_description(query_img_path=temp_path, description=description)

        return JSONResponse(content=response)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error finding similar images: {str(e)}")


# Endpoint for generating a summary (Placeholder for future use)
@app.post("/generate-summary")
async def generate_summary(input: TextInput):
    """
    API endpoint to generate a summary based on text input.
    (This can be used for future functionality or other purposes)
    """
    try:
        # Example processing for summary generation
        summary = input.text[:100]  # Just taking first 100 chars as an example
        return {"summary": summary}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating summary: {str(e)}")


if __name__ == "__main__":
    # Run using uvicorn
    # Command: uvicorn app:app --host 0.0.0.0 --port 8000
    pass
